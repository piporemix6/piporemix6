import { 
  type User, 
  type InsertUser,
  type JournalEntry,
  type InsertJournalEntry,
  type Reminder,
  type InsertReminder,
  type Todo,
  type InsertTodo,
  type CalendarEvent,
  type InsertCalendarEvent,
  type ChatMessage,
  type InsertChatMessage,
  type RecognizedName,
  type InsertRecognizedName,
  type PendingClarification,
  type InsertPendingClarification
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStreak(userId: string, streak: number): Promise<User | undefined>;

  // Journal operations
  getJournalEntries(userId: string): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;

  // Reminder operations  
  getReminders(userId: string): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined>;
  deleteReminder(id: string): Promise<void>;

  // Todo operations
  getTodos(userId: string): Promise<Todo[]>;
  createTodo(todo: InsertTodo): Promise<Todo>;
  updateTodo(id: string, updates: Partial<Todo>): Promise<Todo | undefined>;
  deleteTodo(id: string): Promise<void>;

  // Calendar operations
  getCalendarEvents(userId: string): Promise<CalendarEvent[]>;
  createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent>;
  updateCalendarEvent(id: string, updates: Partial<CalendarEvent>): Promise<CalendarEvent | undefined>;
  deleteCalendarEvent(id: string): Promise<void>;

  // Chat operations
  getChatMessages(userId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Recognized names operations
  getRecognizedNames(userId: string): Promise<RecognizedName[]>;
  getRecognizedNameByName(userId: string, name: string): Promise<RecognizedName | undefined>;
  createRecognizedName(recognizedName: InsertRecognizedName): Promise<RecognizedName>;
  updateRecognizedName(id: string, updates: Partial<RecognizedName>): Promise<RecognizedName | undefined>;

  // Pending clarifications operations
  getPendingClarification(userId: string): Promise<PendingClarification | undefined>;
  createPendingClarification(clarification: InsertPendingClarification): Promise<PendingClarification>;
  deletePendingClarification(id: string): Promise<void>;
  clearUserPendingClarifications(userId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private journalEntries: Map<string, JournalEntry>;
  private reminders: Map<string, Reminder>;
  private todos: Map<string, Todo>;
  private calendarEvents: Map<string, CalendarEvent>;
  private chatMessages: Map<string, ChatMessage>;
  private recognizedNames: Map<string, RecognizedName>;
  private pendingClarifications: Map<string, PendingClarification>;

  constructor() {
    this.users = new Map();
    this.journalEntries = new Map();
    this.reminders = new Map();
    this.todos = new Map();
    this.calendarEvents = new Map();
    this.chatMessages = new Map();
    this.recognizedNames = new Map();
    this.pendingClarifications = new Map();

    // Create default user for demo
    const defaultUser: User = {
      id: "default-user",
      username: "demo",
      name: "Demo User",
      streak: 7,
      lastJournalDate: new Date(),
      createdAt: new Date(),
    };
    this.users.set(defaultUser.id, defaultUser);

    // Create initial chat messages
    const welcomeMessage: ChatMessage = {
      id: "welcome-1",
      userId: "default-user",
      content: "Hey buddy! 🐧 I'm so excited to help you journal today! What's on your mind?",
      isFromPipo: true,
      messageType: "text",
      createdAt: new Date(),
    };
    this.chatMessages.set(welcomeMessage.id, welcomeMessage);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      streak: 0,
      lastJournalDate: null,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStreak(userId: string, streak: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      const updatedUser = { ...user, streak, lastJournalDate: new Date() };
      this.users.set(userId, updatedUser);
      return updatedUser;
    }
    return undefined;
  }

  async getJournalEntries(userId: string): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values()).filter(
      (entry) => entry.userId === userId
    );
  }

  async createJournalEntry(insertEntry: InsertJournalEntry): Promise<JournalEntry> {
    const id = randomUUID();
    const entry: JournalEntry = { 
      ...insertEntry, 
      id, 
      mood: insertEntry.mood ?? null,
      isVoiceRecorded: insertEntry.isVoiceRecorded ?? false,
      createdAt: new Date() 
    };
    this.journalEntries.set(id, entry);
    return entry;
  }

  async getReminders(userId: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(
      (reminder) => reminder.userId === userId
    );
  }

  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = randomUUID();
    const reminder: Reminder = { 
      ...insertReminder, 
      id, 
      description: insertReminder.description ?? null,
      isCompleted: insertReminder.isCompleted ?? false,
      fromPipo: insertReminder.fromPipo ?? false,
      createdAt: new Date() 
    };
    this.reminders.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined> {
    const reminder = this.reminders.get(id);
    if (reminder) {
      const updatedReminder = { ...reminder, ...updates };
      this.reminders.set(id, updatedReminder);
      return updatedReminder;
    }
    return undefined;
  }

  async deleteReminder(id: string): Promise<void> {
    this.reminders.delete(id);
  }

  async getTodos(userId: string): Promise<Todo[]> {
    return Array.from(this.todos.values()).filter(
      (todo) => todo.userId === userId
    );
  }

  async createTodo(insertTodo: InsertTodo): Promise<Todo> {
    const id = randomUUID();
    const todo: Todo = { 
      ...insertTodo, 
      id, 
      description: insertTodo.description ?? null,
      isCompleted: insertTodo.isCompleted ?? false,
      priority: insertTodo.priority ?? "medium",
      createdAt: new Date() 
    };
    this.todos.set(id, todo);
    return todo;
  }

  async updateTodo(id: string, updates: Partial<Todo>): Promise<Todo | undefined> {
    const todo = this.todos.get(id);
    if (todo) {
      const updatedTodo = { ...todo, ...updates };
      this.todos.set(id, updatedTodo);
      return updatedTodo;
    }
    return undefined;
  }

  async deleteTodo(id: string): Promise<void> {
    this.todos.delete(id);
  }

  async getCalendarEvents(userId: string): Promise<CalendarEvent[]> {
    return Array.from(this.calendarEvents.values()).filter(
      (event) => event.userId === userId
    );
  }

  async createCalendarEvent(insertEvent: InsertCalendarEvent): Promise<CalendarEvent> {
    const id = randomUUID();
    const event: CalendarEvent = { 
      ...insertEvent, 
      id, 
      description: insertEvent.description ?? null,
      location: insertEvent.location ?? null,
      createdAt: new Date() 
    };
    this.calendarEvents.set(id, event);
    return event;
  }

  async updateCalendarEvent(id: string, updates: Partial<CalendarEvent>): Promise<CalendarEvent | undefined> {
    const event = this.calendarEvents.get(id);
    if (event) {
      const updatedEvent = { ...event, ...updates };
      this.calendarEvents.set(id, updatedEvent);
      return updatedEvent;
    }
    return undefined;
  }

  async deleteCalendarEvent(id: string): Promise<void> {
    this.calendarEvents.delete(id);
  }

  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter((message) => message.userId === userId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage, 
      id, 
      isFromPipo: insertMessage.isFromPipo ?? false,
      messageType: insertMessage.messageType ?? "text",
      createdAt: new Date() 
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getRecognizedNames(userId: string): Promise<RecognizedName[]> {
    return Array.from(this.recognizedNames.values()).filter(
      (name) => name.userId === userId
    );
  }

  async getRecognizedNameByName(userId: string, name: string): Promise<RecognizedName | undefined> {
    return Array.from(this.recognizedNames.values()).find(
      (recognizedName) => recognizedName.userId === userId && recognizedName.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createRecognizedName(insertRecognizedName: InsertRecognizedName): Promise<RecognizedName> {
    const id = randomUUID();
    const recognizedName: RecognizedName = { 
      ...insertRecognizedName, 
      id, 
      relationship: insertRecognizedName.relationship ?? null,
      context: insertRecognizedName.context ?? null,
      mentionCount: insertRecognizedName.mentionCount ?? 1,
      lastMentioned: new Date(),
      createdAt: new Date() 
    };
    this.recognizedNames.set(id, recognizedName);
    return recognizedName;
  }

  async updateRecognizedName(id: string, updates: Partial<RecognizedName>): Promise<RecognizedName | undefined> {
    const recognizedName = this.recognizedNames.get(id);
    if (recognizedName) {
      const updatedRecognizedName = { ...recognizedName, ...updates, lastMentioned: new Date() };
      this.recognizedNames.set(id, updatedRecognizedName);
      return updatedRecognizedName;
    }
    return undefined;
  }

  async getPendingClarification(userId: string): Promise<PendingClarification | undefined> {
    return Array.from(this.pendingClarifications.values()).find(
      (clarification) => clarification.userId === userId
    );
  }

  async createPendingClarification(insertClarification: InsertPendingClarification): Promise<PendingClarification> {
    // Clear any existing clarifications for this user first
    await this.clearUserPendingClarifications(insertClarification.userId);
    
    const id = randomUUID();
    const clarification: PendingClarification = {
      ...insertClarification,
      id,
      createdAt: new Date()
    };
    this.pendingClarifications.set(id, clarification);
    return clarification;
  }

  async deletePendingClarification(id: string): Promise<void> {
    this.pendingClarifications.delete(id);
  }

  async clearUserPendingClarifications(userId: string): Promise<void> {
    const userClarifications = Array.from(this.pendingClarifications.values())
      .filter(c => c.userId === userId);
    
    for (const clarification of userClarifications) {
      this.pendingClarifications.delete(clarification.id);
    }
  }
}

export const storage = new MemStorage();
