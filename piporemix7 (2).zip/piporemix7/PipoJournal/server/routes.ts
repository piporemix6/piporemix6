import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertChatMessageSchema, insertReminderSchema, insertTodoSchema, insertCalendarEventSchema } from "@shared/schema";
import { parseIndonesianTime, createJakartaDate } from "./IndonesianTemporalInterpreter";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Get current user (demo user for now)
  app.get("/api/user/current", async (req, res) => {
    try {
      const user = await storage.getUser("default-user");
      res.json(user);
    } catch (error) {
      console.error('Error in GET /api/user/current:', error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Get chat messages
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages("default-user");
      res.json(messages);
    } catch (error) {
      console.error('Error in GET /api/chat/messages:', error);
      res.status(500).json({ message: "Failed to get chat messages" });
    }
  });

  // Send chat message
  app.post("/api/chat/messages", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const userMessage = await storage.createChatMessage(validatedData);

      // Check for automatic reminder/calendar creation
      let autoCreations: AutoCreation[] = [];
      try {
        autoCreations = await processAutoCreations(validatedData.content, "default-user");
      } catch (error) {
        console.error('Error in processAutoCreations:', error);
      }

      // Extract and track names from the message
      try {
        await extractAndTrackNames(validatedData.content, "default-user");
      } catch (error) {
        console.error('Error in extractAndTrackNames:', error);
      }

      // Generate Pipo's response
      const pipoResponse = generatePipoResponse(validatedData.content, autoCreations);
      const pipoMessage = await storage.createChatMessage({
        userId: "default-user",
        content: pipoResponse,
        isFromPipo: true,
        messageType: "text",
      });

      res.json({ 
        userMessage, 
        pipoMessage,
        autoCreations: autoCreations
      });
    } catch (error) {
      console.error('Error in POST /api/chat/messages:', error);
      res.status(400).json({ message: "Failed to send message" });
    }
  });

  // Get reminders
  app.get("/api/reminders", async (req, res) => {
    try {
      const reminders = await storage.getReminders("default-user");
      res.json(reminders);
    } catch (error) {
      console.error('Error in GET /api/reminders:', error);
      res.status(500).json({ message: "Failed to get reminders" });
    }
  });

  // Create reminder
  app.post("/api/reminders", async (req, res) => {
    try {
      const validatedData = insertReminderSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const reminder = await storage.createReminder(validatedData);
      res.json(reminder);
    } catch (error) {
      console.error('Error in POST /api/reminders:', error);
      res.status(400).json({ message: "Failed to create reminder" });
    }
  });

  // Update reminder
  app.patch("/api/reminders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const reminder = await storage.updateReminder(id, req.body);
      
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      
      res.json(reminder);
    } catch (error) {
      console.error('Error in PATCH /api/reminders/:id:', error);
      res.status(400).json({ message: "Failed to update reminder" });
    }
  });

  // Delete reminder
  app.delete("/api/reminders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteReminder(id);
      res.json({ message: "Reminder deleted successfully" });
    } catch (error) {
      console.error('Error in DELETE /api/reminders/:id:', error);
      res.status(500).json({ message: "Failed to delete reminder" });
    }
  });

  // Get todos
  app.get("/api/todos", async (req, res) => {
    try {
      const todos = await storage.getTodos("default-user");
      res.json(todos);
    } catch (error) {
      console.error('Error in GET /api/todos:', error);
      res.status(500).json({ message: "Failed to get todos" });
    }
  });

  // Create todo
  app.post("/api/todos", async (req, res) => {
    try {
      const validatedData = insertTodoSchema.parse({
        ...req.body,
        userId: "default-user",
      });

      const todo = await storage.createTodo(validatedData);
      res.json(todo);
    } catch (error) {
      console.error('Error in POST /api/todos:', error);
      res.status(400).json({ message: "Failed to create todo" });
    }
  });

  // Update todo
  app.patch("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const todo = await storage.updateTodo(id, req.body);
      
      if (!todo) {
        return res.status(404).json({ message: "Todo not found" });
      }
      
      res.json(todo);
    } catch (error) {
      console.error('Error in PATCH /api/todos/:id:', error);
      res.status(400).json({ message: "Failed to update todo" });
    }
  });

  // Delete todo
  app.delete("/api/todos/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTodo(id);
      res.json({ message: "Todo deleted successfully" });
    } catch (error) {
      console.error('Error in DELETE /api/todos/:id:', error);
      res.status(500).json({ message: "Failed to delete todo" });
    }
  });

  // Get calendar events
  app.get("/api/calendar/events", async (req, res) => {
    try {
      const events = await storage.getCalendarEvents("default-user");
      res.json(events);
    } catch (error) {
      console.error('Error in GET /api/calendar/events:', error);
      res.status(500).json({ message: "Failed to get calendar events" });
    }
  });

  // Create calendar event
  app.post("/api/calendar/events", async (req, res) => {
    try {
      const startTimeStr = req.body.startTime;
      const endTimeStr = req.body.endTime;
      
      const startTimeParts = startTimeStr.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
      const endTimeParts = endTimeStr.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
      
      if (!startTimeParts || !endTimeParts) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const startDate = `${startTimeParts[1]}-${startTimeParts[2]}-${startTimeParts[3]}`;
      const startTime = `${startTimeParts[4]}:${startTimeParts[5]}`;
      const endDate = `${endTimeParts[1]}-${endTimeParts[2]}-${endTimeParts[3]}`;
      const endTime = `${endTimeParts[4]}:${endTimeParts[5]}`;
      
      const validatedData = insertCalendarEventSchema.parse({
        ...req.body,
        userId: "default-user",
        startTime: createJakartaDate(startDate, startTime),
        endTime: createJakartaDate(endDate, endTime),
      });

      const event = await storage.createCalendarEvent(validatedData);
      res.json(event);
    } catch (error) {
      console.error('Error in POST /api/calendar/events:', error);
      res.status(400).json({ message: "Failed to create calendar event" });
    }
  });

  // Update calendar event
  app.patch("/api/calendar/events/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = { ...req.body };
      
      // Convert string dates to Date objects if present, using Jakarta timezone
      if (updates.startTime) {
        const startTimeParts = updates.startTime.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
        if (startTimeParts) {
          const startDate = `${startTimeParts[1]}-${startTimeParts[2]}-${startTimeParts[3]}`;
          const startTime = `${startTimeParts[4]}:${startTimeParts[5]}`;
          updates.startTime = createJakartaDate(startDate, startTime);
        } else {
          updates.startTime = new Date(updates.startTime);
        }
      }
      if (updates.endTime) {
        const endTimeParts = updates.endTime.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
        if (endTimeParts) {
          const endDate = `${endTimeParts[1]}-${endTimeParts[2]}-${endTimeParts[3]}`;
          const endTime = `${endTimeParts[4]}:${endTimeParts[5]}`;
          updates.endTime = createJakartaDate(endDate, endTime);
        } else {
          updates.endTime = new Date(updates.endTime);
        }
      }
      
      const event = await storage.updateCalendarEvent(id, updates);
      
      if (!event) {
        return res.status(404).json({ message: "Calendar event not found" });
      }
      
      res.json(event);
    } catch (error) {
      console.error('Error in PATCH /api/calendar/events/:id:', error);
      res.status(400).json({ message: "Failed to update calendar event" });
    }
  });

  // Delete calendar event
  app.delete("/api/calendar/events/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCalendarEvent(id);
      res.json({ message: "Calendar event deleted successfully" });
    } catch (error) {
      console.error('Error in DELETE /api/calendar/events/:id:', error);
      res.status(500).json({ message: "Failed to delete calendar event" });
    }
  });

  // Parse Indonesian time expression for calendar
  app.post("/api/parse-time", async (req, res) => {
    try {
      const { timeExpression, referenceDate } = req.body;
      
      if (!timeExpression) {
        return res.status(400).json({ message: "timeExpression is required" });
      }

      const reference = referenceDate ? new Date(referenceDate) : new Date();
      const parseResult = parseIndonesianTime(timeExpression, reference);
      
      res.json(parseResult);
    } catch (error) {
      console.error('Error in POST /api/parse-time:', error);
      res.status(500).json({ message: "Failed to parse time expression" });
    }
  });

  return httpServer;
}

interface AutoCreation {
  type: 'reminder' | 'calendar' | 'todo' | 'clarification_needed';
  title: string;
  description?: string;
  dueDate?: Date;
  startTime?: Date;
  endTime?: Date;
  created: boolean;
  clarificationPrompt?: string;
}

async function processClarificationAnswer(
  userMessage: string, 
  clarification: any, 
  userId: string
): Promise<AutoCreation[] | null> {
  try {
    const partialData = JSON.parse(clarification.partialData);
    console.log('🔄 Processing clarification answer for:', clarification.waitingFor);
    console.log('🔄 Partial data:', partialData);
    console.log('🔄 User answer:', userMessage);

    // Try to parse the user's message as a time answer
    if (clarification.waitingFor === 'time') {
      const parseResult = parseIndonesianTime(`${partialData.activityText} ${userMessage}`);
      
      if (parseResult.status === 'resolved' && parseResult.isoDate && parseResult.isoTime) {
        const dueDate = createJakartaDate(parseResult.isoDate, parseResult.isoTime);
        const reminderTitle = parseResult.formattedReminder || 
          `${partialData.activityText} — ${parseResult.isoDate} — ${parseResult.isoTime}`;
        
        await storage.createReminder({
          userId: userId,
          title: reminderTitle,
          description: `Auto-created from clarification: "${clarification.originalMessage}" + "${userMessage}"`,
          dueDate: dueDate,
          fromPipo: true,
          isCompleted: false
        });
        
        return [{
          type: 'reminder',
          title: reminderTitle,
          dueDate: dueDate,
          created: true
        }];
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error processing clarification answer:', error);
    return null;
  }
}

async function processAutoCreations(userMessage: string, userId: string): Promise<AutoCreation[]> {
  const creations: AutoCreation[] = [];
  const lowerMessage = userMessage.toLowerCase();
  
  console.log('🎯 Processing message for auto-creation:', userMessage);
  console.log('🎯 Lowercase message:', lowerMessage);

  // Check for pending clarifications first
  const pendingClarification = await storage.getPendingClarification(userId);
  
  if (pendingClarification) {
    console.log('🔄 Found pending clarification:', pendingClarification);
    
    // Try to process the user's message as an answer to the clarification
    const processed = await processClarificationAnswer(userMessage, pendingClarification, userId);
    
    if (processed) {
      console.log('✅ Successfully processed clarification answer!');
      // Clear the clarification since we've processed it
      await storage.deletePendingClarification(pendingClarification.id);
      return processed;
    } else {
      console.log('❌ Could not process as clarification answer, continuing normal flow...');
      // Clear stale clarification if user moved on to something else
      await storage.deletePendingClarification(pendingClarification.id);
    }
  }

  // Check if message is a reminder request (Indonesian + English)
  const reminderKeywords = [
    'ingetin', 'ngingetin', 'ingatkan', 'remind me', 'reminder', 
    'jangan lupa', 'jgn lupa', 'don\'t forget', 'tolong ingatkan',
    'makan', 'meeting', 'rapat', 'gym', 'olahraga', 'ketemuan', 'temu'
  ];
  
  const isReminderRequest = reminderKeywords.some(keyword => 
    lowerMessage.includes(keyword)
  );
  
  if (isReminderRequest) {
    console.log('🕐 Detected reminder request, using Indonesian parser...');
    
    // Use Indonesian time parser
    const parseResult = parseIndonesianTime(userMessage);
    
    console.log('🕐 Parse result:', parseResult);
    
    if (parseResult.status === 'needs_clarification') {
      // Save pending clarification to database for context-aware conversation
      await storage.createPendingClarification({
        userId: userId,
        contextType: 'reminder',
        partialData: JSON.stringify({
          activityText: parseResult.activityText,
          originalMessage: userMessage
        }),
        waitingFor: 'time',
        originalMessage: userMessage
      });
      
      // Return clarification needed
      creations.push({
        type: 'clarification_needed',
        title: parseResult.activityText,
        created: false,
        clarificationPrompt: parseResult.clarificationPrompt
      });
    } else if (parseResult.status === 'resolved' && parseResult.isoDate && parseResult.isoTime) {
      // Create reminder with resolved time
      try {
        const dueDate = createJakartaDate(parseResult.isoDate, parseResult.isoTime);
        
        // Use formatted reminder as title: "[Activity] — [yyyy-mm-dd] — [HH:mm]"
        const reminderTitle = parseResult.formattedReminder || 
          `${parseResult.activityText} — ${parseResult.isoDate} — ${parseResult.isoTime}`;
        
        await storage.createReminder({
          userId: "default-user",
          title: reminderTitle,
          description: `Auto-created from: "${userMessage}"`,
          dueDate: dueDate,
          fromPipo: true,
          isCompleted: false
        });
        
        console.log('🕐 Successfully created reminder with Indonesian parser!');
        creations.push({
          type: 'reminder',
          title: reminderTitle,
          dueDate: dueDate,
          created: true
        });
      } catch (error) {
        console.log('🕐 Error creating reminder:', error);
        creations.push({
          type: 'reminder',
          title: parseResult.activityText,
          created: false
        });
      }
    }
  }

  // Detect calendar events - enhanced patterns for better recognition (English + Indonesian)
  const calendarPatterns = [
    // English patterns - most specific first
    /(?:meeting|appointment|event|call|session|interview|conference|presentation)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:schedule|book|plan|set up)\s+(?:a\s+)?(.+?)(?:\s+(?:for|on|at|from|starting)\s+(.+?))?(?:\s|$)/i,
    /i have (?:a\s+)?(?:meeting|appointment|event|call|session|interview|conference|presentation|class|lecture)\s+(?:with\s+|about\s+|for\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:class|lecture|workshop|seminar|training)\s+(?:on\s+|about\s+|for\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:exam|test|quiz|midterm|final)\s+(?:for\s+|on\s+|in\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:assignment|homework|project)\s+(?:for\s+|on\s+|in\s+)?(.+?)(?:\s+(?:due|at|on|by)\s+(.+?))?(?:\s|$)/i,
    
    // Activity-based calendar events - capturing activity name properly (2 groups: title, time)
    /((?:basketball|football|soccer|tennis|golf|baseball|volleyball|swimming|running|jogging|cycling|hiking|yoga|gym|workout|exercise)\s+(?:session|practice|game|match|training|class|lessons?)?)(?:\s+with\s+[^,.]+?)?(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /((?:gaming|game)\s+(?:session|night|tournament)?)(?:\s+with\s+[^,.]+?)?(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:coffee|lunch|dinner|brunch)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    /(?:hangout|hang out|meet up|get together)\s+(?:with\s+)?(.+?)(?:\s+(?:at|on|from|starting)\s+(.+?))?(?:\s|$)/i,
    
    // Indonesian patterns (standard + slang)
    /(?:rapat|meeting|pertemuan|janji|acara)\s+(?:sama|dengan|bareng)?\s*(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:jadwalin|jadwalkan|bikin jadwal)\s+(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada|untuk)\s+(.+?))?(?:\s|$)/i,
    /(?:aku|gue|gw|gua|w)\s+(?:ada|punya)\s+(?:rapat|meeting|janji|acara|kelas|kuliah)\s+(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:kelas|kuliah|workshop|seminar|pelatihan)\s+(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:ujian|tes|kuis|uts|uas)\s+(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:tugas|pr|project|proyek)\s+(.+?)(?:\s+(?:deadline|tenggat|jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:ketemu|ketemuan|kopdar|kopi darat)\s+(?:sama|bareng)?\s*(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:nongkrong|ngopi|makan|minum|lunch|dinner)\s+(?:sama|bareng|dengan)?\s*(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i,
    /(?:hangout|jalan-jalan|jalan2)\s+(?:sama|bareng|dengan)?\s*(.+?)(?:\s+(?:jam|pukul|tanggal|di|pada)\s+(.+?))?(?:\s|$)/i
  ];

  for (const pattern of calendarPatterns) {
    const match = userMessage.match(pattern);
    console.log('🎯 Testing calendar pattern:', pattern.source);
    console.log('🎯 Calendar match result:', match);
    if (match) {
      const title = match[1].trim();
      const timeStr = match[2]?.trim();
      
      console.log('🎯 Creating calendar event:', title, 'at time:', timeStr);
      
      try {
        const startTime = parseTimeString(timeStr) || new Date(Date.now() + 60 * 60 * 1000); // Default: 1 hour from now
        const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // Default: 1 hour duration
        
        // Create calendar event
        await storage.createCalendarEvent({
          userId: "default-user",
          title: title,
          description: `Auto-created from: "${userMessage}"`,
          startTime: startTime,
          endTime: endTime,
          location: null
        });

        // Also create a corresponding todo item
        await storage.createTodo({
          userId: "default-user",
          title: `Prepare for: ${title}`,
          description: `Auto-created todo for calendar event: "${title}"`,
          priority: "medium",
          isCompleted: false
        });

        console.log('🎯 Successfully created calendar event and todo!');
        creations.push({
          type: 'calendar',
          title: title,
          startTime: startTime,
          endTime: endTime,
          created: true
        });
        break; // Only create one calendar event per message
      } catch (error) {
        console.log('🎯 Error creating calendar event:', error);
        creations.push({
          type: 'calendar',
          title: title,
          created: false
        });
      }
    }
  }

  // Detect todo items - standalone tasks (not already covered by reminders/calendar)
  // Only create if we haven't already created a reminder or calendar event
  const hasReminderOrCalendar = creations.some(c => 
    (c.type === 'reminder' || c.type === 'calendar') && c.created
  );
  
  if (!hasReminderOrCalendar) {
    const todoPatterns = [
      // English patterns
      /(?:i need to|i have to|i must|i should|i gotta|todo:?|task:?)\s+(.+)/i,
      /(?:need to|have to|must|should|gotta)\s+(.+)/i,
      
      // Indonesian patterns (standard + slang)
      /(?:aku|gue|gw|gua|w|saya)\s+(?:harus|perlu|mesti|kudu|wajib)\s+(.+)/i,
      /(?:harus|perlu|mesti|kudu|wajib)\s+(.+)/i,
      /(?:todo:?|tugas:?|kerjaan:?)\s+(.+)/i,
      /(?:jangan lupa|jgn lupa)\s+(?:buat|untuk)?\s*(.+)/i,
    ];

    for (const pattern of todoPatterns) {
      const match = userMessage.match(pattern);
      console.log('📝 Testing todo pattern:', pattern.source);
      console.log('📝 Todo match result:', match);
      
      if (match) {
        let todoTitle = match[1].trim();
        
        // Clean up the title by removing time-related suffixes
        todoTitle = todoTitle.replace(/\s+(?:jam|pukul|at|on|by)\s+.+$/i, '').trim();
        
        // Skip if the title is too short or empty
        if (todoTitle.length < 3) {
          continue;
        }
        
        console.log('📝 Creating todo:', todoTitle);
        
        // Detect priority from keywords
        let priority: "high" | "medium" | "low" = "medium";
        const lowerTitle = todoTitle.toLowerCase();
        const lowerMessage = userMessage.toLowerCase();
        
        // High priority keywords
        if (lowerMessage.includes('urgent') || lowerMessage.includes('penting') || 
            lowerMessage.includes('segera') || lowerMessage.includes('asap') ||
            lowerMessage.includes('cepat') || lowerMessage.includes('mendesak')) {
          priority = "high";
        }
        // Low priority keywords
        else if (lowerMessage.includes('nanti') || lowerMessage.includes('later') || 
                 lowerMessage.includes('kalau sempat') || lowerMessage.includes('if i have time') ||
                 lowerMessage.includes('someday') || lowerMessage.includes('kapan-kapan')) {
          priority = "low";
        }
        
        try {
          await storage.createTodo({
            userId: "default-user",
            title: todoTitle,
            description: `Auto-created from: "${userMessage}"`,
            priority: priority,
            isCompleted: false
          });
          
          console.log('📝 Successfully created todo with priority:', priority);
          creations.push({
            type: 'todo',
            title: todoTitle,
            created: true
          });
          break; // Only create one todo per message
        } catch (error) {
          console.log('📝 Error creating todo:', error);
          creations.push({
            type: 'todo',
            title: todoTitle,
            created: false
          });
        }
      }
    }
  }

  return creations;
}

function parseTimeString(timeStr?: string): Date | null {
  if (!timeStr) return null;
  
  const now = new Date();
  const lowerTimeStr = timeStr.toLowerCase().trim();
  
  console.log('🎯 Parsing time string:', timeStr);
  
  // Handle specific time formats like "5:30 PM", "10 AM", "2:15 PM"
  const timeRegex = /(\d{1,2}):?(\d{2})?\s*(am|pm)/i;
  const timeMatch = lowerTimeStr.match(timeRegex);
  
  if (timeMatch) {
    const hour = parseInt(timeMatch[1]);
    const minute = parseInt(timeMatch[2] || '0');
    const isPM = timeMatch[3].toLowerCase() === 'pm';
    
    let adjustedHour = hour;
    if (isPM && hour !== 12) {
      adjustedHour += 12;
    } else if (!isPM && hour === 12) {
      adjustedHour = 0;
    }
    
    const timeDate = new Date(now);
    timeDate.setHours(adjustedHour, minute, 0, 0);
    
    // If the time has already passed today, set it for tomorrow
    if (timeDate <= now) {
      timeDate.setDate(timeDate.getDate() + 1);
    }
    
    console.log('🎯 Parsed time:', timeDate);
    return timeDate;
  }
  
  // Handle 24-hour format like "14:30", "09:15"
  const time24Regex = /(\d{1,2}):(\d{2})/;
  const time24Match = lowerTimeStr.match(time24Regex);
  
  if (time24Match) {
    const hour = parseInt(time24Match[1]);
    const minute = parseInt(time24Match[2]);
    
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
      const timeDate = new Date(now);
      timeDate.setHours(hour, minute, 0, 0);
      
      // If the time has already passed today, set it for tomorrow
      if (timeDate <= now) {
        timeDate.setDate(timeDate.getDate() + 1);
      }
      
      console.log('🎯 Parsed 24h time:', timeDate);
      return timeDate;
    }
  }
  
  // Handle relative times (English + Indonesian)
  if (lowerTimeStr.includes('tomorrow') || lowerTimeStr.includes('besok')) {
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(9, 0, 0, 0); // Default to 9 AM
    return tomorrow;
  }
  
  if (lowerTimeStr.includes('lusa') || lowerTimeStr.includes('day after tomorrow')) {
    const dayAfterTomorrow = new Date(now);
    dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);
    dayAfterTomorrow.setHours(9, 0, 0, 0);
    return dayAfterTomorrow;
  }
  
  if (lowerTimeStr.includes('next week') || lowerTimeStr.includes('minggu depan')) {
    const nextWeek = new Date(now);
    nextWeek.setDate(nextWeek.getDate() + 7);
    nextWeek.setHours(9, 0, 0, 0);
    return nextWeek;
  }

  // Handle day names (English + Indonesian)
  const dayNames = {
    'sunday': 0, 'minggu': 0,
    'monday': 1, 'senin': 1,
    'tuesday': 2, 'selasa': 2,
    'wednesday': 3, 'rabu': 3,
    'thursday': 4, 'kamis': 4,
    'friday': 5, 'jumat': 5, 'jum\'at': 5,
    'saturday': 6, 'sabtu': 6
  };
  
  for (const [dayName, dayIndex] of Object.entries(dayNames)) {
    if (lowerTimeStr.includes(dayName)) {
      const targetDay = new Date(now);
      const daysUntilTarget = (dayIndex + 7 - targetDay.getDay()) % 7 || 7;
      targetDay.setDate(targetDay.getDate() + daysUntilTarget);
      targetDay.setHours(9, 0, 0, 0);
      return targetDay;
    }
  }
  
  // Handle Indonesian time phrases
  if (lowerTimeStr.includes('pagi')) {
    const morning = new Date(now);
    morning.setHours(9, 0, 0, 0);
    if (morning <= now) morning.setDate(morning.getDate() + 1);
    return morning;
  }
  
  if (lowerTimeStr.includes('siang')) {
    const noon = new Date(now);
    noon.setHours(12, 0, 0, 0);
    if (noon <= now) noon.setDate(noon.getDate() + 1);
    return noon;
  }
  
  if (lowerTimeStr.includes('sore')) {
    const afternoon = new Date(now);
    afternoon.setHours(16, 0, 0, 0);
    if (afternoon <= now) afternoon.setDate(afternoon.getDate() + 1);
    return afternoon;
  }
  
  if (lowerTimeStr.includes('malam')) {
    const evening = new Date(now);
    evening.setHours(19, 0, 0, 0);
    if (evening <= now) evening.setDate(evening.getDate() + 1);
    return evening;
  }
  
  // Handle "jam X" format (Indonesian)
  const jamRegex = /(?:jam|pukul)\s+(\d{1,2})/i;
  const jamMatch = lowerTimeStr.match(jamRegex);
  if (jamMatch) {
    const hour = parseInt(jamMatch[1]);
    const timeDate = new Date(now);
    timeDate.setHours(hour, 0, 0, 0);
    if (timeDate <= now) timeDate.setDate(timeDate.getDate() + 1);
    return timeDate;
  }

  // Handle "in X hours/minutes"
  const inTimeRegex = /in\s+(\d+)\s+(hour|hours|minute|minutes)/i;
  const inTimeMatch = lowerTimeStr.match(inTimeRegex);
  
  if (inTimeMatch) {
    const amount = parseInt(inTimeMatch[1]);
    const unit = inTimeMatch[2].toLowerCase();
    const futureTime = new Date(now);
    
    if (unit.includes('hour')) {
      futureTime.setHours(futureTime.getHours() + amount);
    } else if (unit.includes('minute')) {
      futureTime.setMinutes(futureTime.getMinutes() + amount);
    }
    
    return futureTime;
  }

  // Try to parse as a regular date
  try {
    const parsed = new Date(timeStr);
    if (!isNaN(parsed.getTime())) {
      return parsed;
    }
  } catch (error) {
    // Ignore parsing errors
  }
  
  console.log('🎯 Could not parse time string');
  return null;
}

// Function to extract and track names from messages
async function extractAndTrackNames(userMessage: string, userId: string = "default-user") {
  // Common name patterns - look for capitalized words that might be names
  const namePatterns = [
    // More specific patterns to avoid false positives
    /(?:my friend|my buddy|friend|buddy)\s+([A-Z][a-z]+)/gi,
    /(?:my|our)\s+(?:brother|sister|cousin|uncle|aunt|grandpa|grandma)\s+([A-Z][a-z]+)/gi,
    /(?:with|see|call|text|message|visit)\s+(?:my friend\s+)?([A-Z][a-z]{2,})/gi,
    // Direct mentions with "and"
    /([A-Z][a-z]{2,})\s+(?:and I|and me)/gi,
    /(?:I and|me and)\s+([A-Z][a-z]{2,})/gi,
  ];

  const foundNames = new Set<string>();

  // Extract names using patterns
  for (const pattern of namePatterns) {
    let match;
    pattern.lastIndex = 0; // Reset pattern for global search
    while ((match = pattern.exec(userMessage)) !== null) {
      if (match[1]) {
        foundNames.add(match[1]);
      }
    }
  }

  console.log('🎯 Found potential names:', Array.from(foundNames));

  // Process each found name
  const namesArray = Array.from(foundNames);
  for (let i = 0; i < namesArray.length; i++) {
    const name = namesArray[i];
    // Skip common words that aren't names - expanded list
    const commonWords = [
      'Today', 'Tomorrow', 'Yesterday', 
      'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday',
      'At', 'In', 'On', 'To', 'From', 'With', 'For', 'Of', 'The', 'And', 'Or',
      'My', 'Your', 'His', 'Her', 'Their', 'Our',
      'Mad', 'Sad', 'Happy', 'Angry', 'Excited', 'Tired',
      'Good', 'Bad', 'Great', 'Nice', 'Fine',
      'Meeting', 'Call', 'Session', 'Event'
    ];
    if (commonWords.includes(name)) {
      continue;
    }
    
    // Minimum length check - names should be at least 3 characters
    if (name.length < 3) {
      continue;
    }

    try {
      // Check if this name already exists
      const existing = await storage.getRecognizedNameByName(userId, name);
      
      if (existing) {
        // Update mention count and context
        const newContext = existing.context ? `${existing.context}; ${userMessage}` : userMessage;
        await storage.updateRecognizedName(existing.id, {
          mentionCount: existing.mentionCount + 1,
          context: newContext.length > 500 ? newContext.substring(0, 500) + '...' : newContext
        });
        console.log('🎯 Updated existing name:', name);
      } else {
        // Create new recognized name
        let relationship = 'unknown';
        const lowerMessage = userMessage.toLowerCase();
        
        // Try to determine relationship from context
        if (lowerMessage.includes('friend') || lowerMessage.includes('buddy')) {
          relationship = 'friend';
        } else if (lowerMessage.includes('family') || lowerMessage.includes('brother') || lowerMessage.includes('sister') || lowerMessage.includes('mom') || lowerMessage.includes('dad')) {
          relationship = 'family';
        } else if (lowerMessage.includes('colleague') || lowerMessage.includes('coworker') || lowerMessage.includes('work')) {
          relationship = 'colleague';
        } else if (lowerMessage.includes('game') || lowerMessage.includes('gaming') || lowerMessage.includes('play')) {
          relationship = 'gaming_friend';
        }

        await storage.createRecognizedName({
          userId,
          name,
          relationship,
          context: userMessage,
          mentionCount: 1
        });
        console.log('🎯 Created new recognized name:', name, 'with relationship:', relationship);
      }
    } catch (error) {
      console.log('🎯 Error processing name:', name, error);
    }
  }

  return Array.from(foundNames);
}

// Function to detect language from user message
function detectLanguage(message: string): 'id' | 'en' {
  const lowerMessage = message.toLowerCase();
  
  // Indonesian indicators (including slang)
  const indonesianWords = [
    // Standard Indonesian
    'aku', 'saya', 'kamu', 'anda', 'dia', 'mereka', 'kita', 'kami',
    'ini', 'itu', 'yang', 'untuk', 'dengan', 'dari', 'ke', 'di', 'pada',
    'sudah', 'belum', 'sedang', 'akan', 'bisa', 'mau', 'ingin',
    'bagaimana', 'kapan', 'dimana', 'kenapa', 'siapa', 'apa',
    'hari', 'minggu', 'bulan', 'tahun', 'besok', 'kemarin',
    // Indonesian slang
    'gue', 'gw', 'gua', 'lu', 'lo', 'loe', 'elu',
    'gak', 'ngga', 'nggak', 'engga', 'enggak', 'ga',
    'udah', 'udh', 'dah', 'emang', 'emg', 'gimana', 'gmn',
    'pengen', 'pengin', 'pgn', 'mau', 'mo',
    'aja', 'aj', 'dong', 'deh', 'sih', 'kok', 'kan',
    'banget', 'bgt', 'bener', 'beneran', 'bikin',
    'tau', 'tahu', 'ngerti', 'ngarti', 'paham',
    'lagi', 'lg', 'sama', 'sm', 'kayak', 'kaya', 'kyk',
    'buat', 'bikin', 'jadi', 'jd', 'terus', 'trus',
    'abis', 'habis', 'selesai',
    'ingetin', 'ngingetin', 'reminder',
    'jadwal', 'jadwalin', 'appointment'
  ];
  
  // Count Indonesian word matches
  let indonesianCount = 0;
  for (const word of indonesianWords) {
    if (lowerMessage.includes(word)) {
      indonesianCount++;
    }
  }
  
  // If we find at least 2 Indonesian words, it's Indonesian
  return indonesianCount >= 2 ? 'id' : 'en';
}

// Function to normalize Indonesian slang to standard form for better pattern matching
function normalizeIndonesianSlang(message: string): string {
  const slangMap: { [key: string]: string } = {
    // Pronouns
    'gue': 'saya', 'gw': 'saya', 'gua': 'saya',
    'lu': 'kamu', 'lo': 'kamu', 'loe': 'kamu', 'elu': 'kamu',
    // Negations
    'gak': 'tidak', 'ngga': 'tidak', 'nggak': 'tidak', 
    'engga': 'tidak', 'enggak': 'tidak', 'ga': 'tidak',
    // Common words
    'udah': 'sudah', 'udh': 'sudah', 'dah': 'sudah',
    'emang': 'memang', 'emg': 'memang',
    'gimana': 'bagaimana', 'gmn': 'bagaimana',
    'pengen': 'ingin', 'pengin': 'ingin', 'pgn': 'ingin',
    'aja': 'saja', 'aj': 'saja',
    'banget': 'sangat', 'bgt': 'sangat',
    'bener': 'benar', 'beneran': 'benar',
    'tau': 'tahu', 'ngerti': 'mengerti',
    'lagi': 'sedang', 'lg': 'sedang',
    'sama': 'dengan', 'sm': 'dengan',
    'kayak': 'seperti', 'kaya': 'seperti', 'kyk': 'seperti',
    'buat': 'untuk', 'jadi': 'menjadi', 'jd': 'jadi',
    'terus': 'lalu', 'trus': 'lalu',
    'abis': 'setelah', 'habis': 'setelah',
    'ingetin': 'ingatkan', 'ngingetin': 'ingatkan'
  };
  
  let normalized = message;
  for (const [slang, standard] of Object.entries(slangMap)) {
    const regex = new RegExp(`\\b${slang}\\b`, 'gi');
    normalized = normalized.replace(regex, standard);
  }
  
  return normalized;
}

function generatePipoResponse(userMessage: string, autoCreations: AutoCreation[] = []): string {
  const language = detectLanguage(userMessage);
  const lowerMessage = userMessage.toLowerCase();
  const normalizedMessage = language === 'id' ? normalizeIndonesianSlang(lowerMessage) : lowerMessage;
  
  // Check if clarification is needed
  const needsClarification = autoCreations.find(c => c.type === 'clarification_needed');
  if (needsClarification && needsClarification.clarificationPrompt) {
    return needsClarification.clarificationPrompt;
  }
  
  // If we created something automatically, acknowledge it
  if (autoCreations.length > 0) {
    const successful = autoCreations.filter(c => c.created);
    if (successful.length > 0) {
      const types = successful.map(c => c.type);
      const reminderCount = types.filter(t => t === 'reminder').length;
      const calendarCount = types.filter(t => t === 'calendar').length;
      const todoCount = types.filter(t => t === 'todo').length;
      
      if (language === 'id') {
        let response = "Sempurna! Aku sudah siapkan! 🐧✨ Aku otomatis buatkan ";
        
        const items = [];
        if (reminderCount > 0) items.push(`${reminderCount} pengingat`);
        if (calendarCount > 0) items.push(`${calendarCount} jadwal`);
        if (todoCount > 0) items.push(`${todoCount} to-do`);
        
        if (items.length === 1) {
          response += `${items[0]} untuk kamu! `;
        } else if (items.length === 2) {
          response += `${items[0]} dan ${items[1]} untuk kamu! `;
        } else if (items.length === 3) {
          response += `${items[0]}, ${items[1]}, dan ${items[2]} untuk kamu! `;
        }
        
        response += "Cek tab kamu untuk lihatnya! Aku seneng banget bisa bantu kamu tetap terorganisir! 📅🔔✅";
        return response;
      } else {
        let response = "Perfect! I've got you covered! 🐧✨ I automatically created ";
        
        const items = [];
        if (reminderCount > 0) items.push(`${reminderCount} reminder${reminderCount > 1 ? 's' : ''}`);
        if (calendarCount > 0) items.push(`${calendarCount} calendar event${calendarCount > 1 ? 's' : ''}`);
        if (todoCount > 0) items.push(`${todoCount} to-do${todoCount > 1 ? 's' : ''}`);
        
        if (items.length === 1) {
          response += `${items[0]} for you! `;
        } else if (items.length === 2) {
          response += `${items[0]} and ${items[1]} for you! `;
        } else if (items.length === 3) {
          response += `${items[0]}, ${items[1]}, and ${items[2]} for you! `;
        }
        
        response += "Check your tabs to see them! I love keeping you organized! 📅🔔✅";
        return response;
      }
    }
  }
  
  // Positive/achievement responses
  if (normalizedMessage.includes("promoted") || normalizedMessage.includes("achievement") || normalizedMessage.includes("success") ||
      normalizedMessage.includes("naik jabatan") || normalizedMessage.includes("promosi") || normalizedMessage.includes("berhasil") || 
      normalizedMessage.includes("sukses") || normalizedMessage.includes("menang")) {
    return language === 'id' 
      ? "OMG IYA! 🎉 Itu LUAR BIASA! Kamu emang pantas dapetin itu! Aku lagi joget penguin gembira nih! 🐧💃 Ceritain dong gimana perasaan kamu!"
      : "OMG YES! 🎉 That's INCREDIBLE! You totally deserve it! I'm doing a happy penguin dance right now! 🐧💃 Tell me more about how you're feeling!";
  }
  
  // Sad/difficult responses  
  if (normalizedMessage.includes("sad") || normalizedMessage.includes("difficult") || normalizedMessage.includes("hard") ||
      normalizedMessage.includes("sedih") || normalizedMessage.includes("susah") || normalizedMessage.includes("sulit") ||
      normalizedMessage.includes("berat") || normalizedMessage.includes("galau")) {
    return language === 'id'
      ? "Aduh teman 😞 Aku ngerti kok ini pasti berat buat kamu. Inget ya, aku selalu ada di sini! Mau cerita lebih lanjut gak? 🐧💙"
      : "Oh buddy 😞 I can hear that this is tough for you. Remember, I'm here with you through it all! Want to talk more about what's going on? 🐧💙";
  }
  
  // Schedule/calendar related
  if (normalizedMessage.includes("appointment") || normalizedMessage.includes("meeting") || normalizedMessage.includes("schedule") ||
      normalizedMessage.includes("jadwal") || normalizedMessage.includes("janji") || normalizedMessage.includes("ketemu") ||
      normalizedMessage.includes("rapat")) {
    return language === 'id'
      ? "Siap! 📅 Aku selalu siap bantu kamu tetap teratur! Kasih tau detail lebih lanjut dan aku bisa tambahin ke kalender kamu otomatis! 🐧"
      : "Got it! 📅 I'm always ready to help you stay organized! Tell me more details and I can add it to your calendar automatically! 🐧";
  }
  
  // Todo/task related
  if (normalizedMessage.includes("need to") || normalizedMessage.includes("have to") || normalizedMessage.includes("task") ||
      normalizedMessage.includes("harus") || normalizedMessage.includes("perlu") || normalizedMessage.includes("tugas") ||
      normalizedMessage.includes("kerjaan")) {
    return language === 'id'
      ? "Wah, kedengeran penting nih! 📝 Mau aku bantuin ingetin gak? Tinggal bilang 'ingetin aku...' dan aku yang urus! 🐧✨"
      : "Ooh, sounds important! 📝 Want me to help you remember that? Just say 'remind me to...' and I'll take care of it! 🐧✨";
  }
  
  // Default friendly responses
  if (language === 'id') {
    const responses = [
      "Wah menarik banget! 🐧 Ceritain lebih lanjut dong - aku suka banget dengerin isi pikiran kamu!",
      "Wah, makasih udah cerita sama aku! 💙 Gimana perasaan kamu soal itu?",
      "Seneng banget kamu journaling bareng aku hari ini! 🐧 Ada apa lagi nih di dunia kamu?",
      "Kayaknya itu penting buat kamu ya! ✨ Mau bahas lebih dalam gak?",
      "Aku suka ngobrol sama kamu! 🐧💙 Lanjut terus - aku siap dengerin! 👂"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  } else {
    const responses = [
      "That's so interesting! 🐧 Tell me more about that - I love hearing what's on your mind!",
      "Wow, thanks for sharing that with me! 💙 How are you feeling about it?",
      "I'm so glad you're journaling with me today! 🐧 What else is happening in your world?",
      "That sounds important to you! ✨ Want to dive deeper into that thought?",
      "I love our chats! 🐧💙 Keep going - I'm all flippers! 👂"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }
}
