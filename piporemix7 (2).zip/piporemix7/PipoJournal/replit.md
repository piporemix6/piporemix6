# Overview

Pipo is a mobile-first productivity companion application built with React and Express. The app features a penguin mascot named Pipo who helps users manage their daily tasks, reminders, calendar events, and journal entries through an interactive chat interface. The application supports both text and voice interactions, provides streak tracking for journaling habits, and offers a comprehensive suite of productivity tools in a friendly, engaging mobile interface.

# Recent Changes (October 2025)

## Multilingual Support & Indonesian Language
- **Automatic Language Detection**: Pipo now automatically detects the language from user messages and responds in the same language (English or Indonesian)
- **Indonesian Slang Support**: Added comprehensive support for Indonesian slang and colloquial expressions including:
  - Pronouns: gue, gw, gua, lu, lo, loe, elu
  - Negations: gak, ngga, nggak, ga, engga
  - Common words: udah, emang, gimana, pengen, aja, banget, tau, kayak, etc.
- **Normalized Processing**: Slang terms are normalized to standard Indonesian for better pattern recognition
- **Bilingual Responses**: All Pipo responses are now available in both English and Indonesian

## Enhanced Auto-Creation Patterns
- **Indonesian Pattern Recognition**: Added comprehensive Indonesian language patterns for automatic creation of reminders and calendar events
- **Slang-Aware Patterns**: System now understands Indonesian slang in reminder/calendar requests
- **Time Expression Support**: Added Indonesian time expressions (besok, lusa, pagi, siang, sore, malam, jam, pukul, etc.)
- **Day Names**: Support for Indonesian day names (Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu)

## Direct Edit & Delete Functionality
- **Reminders Management**: 
  - Added Edit dialog with title, description, and due date fields
  - Delete functionality with confirmation
  - Edit button on each reminder card
  - No need to chat with Pipo to modify reminders
- **Calendar Events Management**:
  - Added Edit dialog with title, description, start/end time, and location fields
  - Delete functionality with confirmation
  - Edit button on each calendar event
  - Direct modification without using chat interface
- **Backend Support**: New API endpoints for deleting reminders and calendar events (DELETE /api/reminders/:id, DELETE /api/calendar/events/:id)

## Bug Fixes (October 17, 2025)
- **Accessibility Improvements**: Added DialogDescription components to all edit dialogs (RemindersTab and CalendarTab) to eliminate accessibility warnings
- **Auto-Creation Pattern Fixes**:
  - Fixed regex patterns that were capturing incorrect title text for activities (gym, swimming, etc.)
  - Pattern now correctly captures activity name as title and time separately
  - Example: "saya ingin gym jam 9 pagi" now correctly creates reminder with title "gym" and time "9 pagi"
- **Enhanced Slang Support in Auto-Creation**:
  - Added support for ultra-casual Indonesian slang in pattern matching
  - Supports pronouns: "w" (saya/aku)
  - Supports verbs: "mo" (mau), variations like "jim/jem" for "gym"
  - Pattern: "w mo jim jem 9 mlm ini, ingetin w ye" now correctly recognized
- **Calendar Pattern Improvements**:
  - Fixed activity-based calendar patterns (swimming lessons, gym session, etc.)
  - Pattern now uses only 2 capture groups (title, time) for consistency
  - Example: "remind me swimming lessons at 9:30 pm" now correctly creates event with title "swimming lessons"

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development
- **UI Components**: Shadcn/UI component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Mobile-First Design**: Responsive design optimized for mobile devices with bottom navigation

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API with JSON responses
- **Development Setup**: Hot module replacement with Vite integration for development
- **Error Handling**: Centralized error handling middleware with structured JSON responses

## Data Storage
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema**: Shared schema definitions between client and server using Drizzle Zod
- **Migration System**: Drizzle Kit for database schema migrations
- **Development Storage**: In-memory storage implementation for development/testing

## Authentication & Session Management
- **Session Storage**: PostgreSQL session store using connect-pg-simple
- **User Management**: Simple user system with streak tracking for engagement
- **Demo Mode**: Default user system for demonstration purposes

## Key Features Architecture
- **Chat System**: Real-time messaging with Pipo mascot, supporting both text and voice input
- **Voice Recognition**: Browser-based speech recognition with fallback text input
- **Productivity Tools**: Integrated reminders, todos, calendar events, and journal entries
- **Streak System**: Gamification through daily journaling streak tracking
- **Mobile Navigation**: Tab-based bottom navigation with badge notifications

## External Dependencies

- **Database**: Neon Database (PostgreSQL-compatible serverless database)
- **UI Components**: Radix UI primitives for accessible component foundations
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation and formatting
- **Voice Input**: Browser Web Speech API for voice recognition functionality
- **Development Tools**: Replit-specific plugins for development environment integration