import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Reminder } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { Check, Clock, Edit, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function RemindersTab() {
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    dueDate: "",
  });

  const { data: reminders, isLoading } = useQuery<Reminder[]>({
    queryKey: ["/api/reminders"],
  });

  const updateReminderMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Reminder> }) => {
      const response = await apiRequest("PATCH", `/api/reminders/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/reminders/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reminders"] });
      setEditingReminder(null);
    },
  });

  const handleToggleComplete = (reminder: Reminder) => {
    updateReminderMutation.mutate({
      id: reminder.id,
      updates: { isCompleted: !reminder.isCompleted }
    });
  };

  const handleEditClick = (reminder: Reminder) => {
    setEditingReminder(reminder);
    setEditForm({
      title: reminder.title,
      description: reminder.description || "",
      dueDate: format(new Date(reminder.dueDate), "yyyy-MM-dd'T'HH:mm"),
    });
  };

  const handleSaveEdit = () => {
    if (!editingReminder) return;

    updateReminderMutation.mutate({
      id: editingReminder.id,
      updates: {
        title: editForm.title,
        description: editForm.description,
        dueDate: new Date(editForm.dueDate),
      },
    });
    setEditingReminder(null);
  };

  const handleDeleteReminder = () => {
    if (!editingReminder) return;

    if (confirm("Are you sure you want to delete this reminder?")) {
      deleteReminderMutation.mutate(editingReminder.id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4 pt-16">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const activeReminders = reminders?.filter(r => !r.isCompleted) || [];
  const completedReminders = reminders?.filter(r => r.isCompleted) || [];

  return (
    <div className="pb-20" data-testid="reminders-tab">
      {/* Header */}
      <div className="bg-gradient-to-br from-amber-700 to-orange-800 p-6 pt-12 pb-7 text-white">
        <div className="flex items-center gap-3.5">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center penguin-float shadow-md">
            <PipoMascot size="medium" expression="happy" />
          </div>
          <div>
            <h1 className="text-2xl font-bold mb-0.5 drop-shadow-sm" data-testid="reminders-title">Reminders 🔔</h1>
            <p className="text-white/95 text-sm">I've got your back, buddy!</p>
          </div>
        </div>
      </div>

      <div className="p-5 space-y-6">
        {/* Active Reminders */}
        {activeReminders.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Upcoming ({activeReminders.length})
            </h2>
            <div className="space-y-3">
              {activeReminders.map((reminder) => (
                <div 
                  key={reminder.id} 
                  className="bg-card border border-border rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                  data-testid={`reminder-${reminder.id}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1" data-testid="reminder-title">
                        {reminder.title}
                      </h3>
                      {reminder.description && (
                        <p className="text-sm text-muted-foreground mb-2.5 leading-relaxed" data-testid="reminder-description">
                          {reminder.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={reminder.fromPipo ? "secondary" : "outline"} className="shadow-sm">
                          {reminder.fromPipo ? "From Pipo 🐧" : "Personal"}
                        </Badge>
                        <span className="text-xs text-muted-foreground" data-testid="reminder-date">
                          {format(new Date(reminder.dueDate), "d MMM yyyy 'at' h:mm a")}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEditClick(reminder)}
                        className="hover:bg-muted/50"
                        data-testid={`button-edit-${reminder.id}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleToggleComplete(reminder)}
                        disabled={updateReminderMutation.isPending}
                        className="shadow-sm"
                        data-testid={`button-complete-${reminder.id}`}
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Reminders */}
        {completedReminders.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Check className="w-5 h-5 text-green-500" />
              Completed ({completedReminders.length})
            </h2>
            <div className="space-y-3">
              {completedReminders.map((reminder) => (
                <div 
                  key={reminder.id} 
                  className="bg-muted/50 border border-border rounded-lg p-4 opacity-75"
                  data-testid={`completed-reminder-${reminder.id}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1 line-through">
                        {reminder.title}
                      </h3>
                      {reminder.description && (
                        <p className="text-sm text-muted-foreground mb-2 line-through">
                          {reminder.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="opacity-50">
                          Completed ✓
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!reminders || reminders.length === 0) && (
          <div className="text-center py-16 px-4" data-testid="empty-reminders">
            <div className="w-20 h-20 bg-gradient-to-br from-muted to-muted/60 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-sm">
              <PipoMascot size="medium" expression="neutral" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No reminders yet!</h3>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto leading-relaxed">
              Chat with Pipo to create reminders, or I'll check in with you soon! 🐧
            </p>
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingReminder} onOpenChange={(open) => !open && setEditingReminder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Reminder</DialogTitle>
            <DialogDescription>
              Update the details of your reminder or delete it if you no longer need it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Title</label>
              <Input
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                placeholder="Reminder title"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Description</label>
              <Textarea
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Additional details (optional)"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Due Date & Time</label>
              <Input
                type="datetime-local"
                value={editForm.dueDate}
                onChange={(e) => setEditForm({ ...editForm, dueDate: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter className="flex gap-2">
            <Button
              variant="destructive"
              onClick={handleDeleteReminder}
              disabled={deleteReminderMutation.isPending}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
            <div className="flex-1" />
            <Button variant="outline" onClick={() => setEditingReminder(null)}>
              Cancel
            </Button>
            <Button
              onClick={handleSaveEdit}
              disabled={!editForm.title || updateReminderMutation.isPending}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
