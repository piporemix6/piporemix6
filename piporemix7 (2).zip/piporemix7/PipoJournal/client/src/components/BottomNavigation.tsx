import { MessageCircle, Bell, Calendar, ListChecks, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Reminder, Todo } from "@shared/schema";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: "chat" | "reminders" | "calendar" | "todos" | "account") => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const { data: reminders } = useQuery<Reminder[]>({
    queryKey: ["/api/reminders"],
  });

  const { data: todos } = useQuery<Todo[]>({
    queryKey: ["/api/todos"],
  });

  const activeRemindersCount = reminders?.filter(r => !r.isCompleted).length || 0;
  const activeTodosCount = todos?.filter(t => !t.isCompleted).length || 0;

  const tabs = [
    {
      id: "chat" as const,
      icon: MessageCircle,
      label: "Chat",
      badge: null,
    },
    {
      id: "reminders" as const,
      icon: Bell,
      label: "Reminders",
      badge: activeRemindersCount > 0 ? activeRemindersCount : null,
    },
    {
      id: "calendar" as const,
      icon: Calendar,
      label: "Calendar",
      badge: null,
    },
    {
      id: "todos" as const,
      icon: ListChecks,
      label: "To-Do",
      badge: activeTodosCount > 0 ? activeTodosCount : null,
    },
    {
      id: "account" as const,
      icon: User,
      label: "Account",
      badge: null,
    },
  ];

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-border shadow-xl" data-testid="bottom-navigation">
      <div className="flex items-center justify-around py-2.5 px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center px-3 py-2 rounded-2xl transition-all duration-300 min-w-0 ${
                isActive 
                  ? 'tab-active text-white shadow-lg scale-105' 
                  : 'text-muted-foreground hover:text-primary hover:bg-muted/50 hover:scale-105'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 mb-1 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {tab.badge && (
                  <div className="absolute -top-2 -right-2 min-w-[20px] h-5 bg-gradient-to-br from-accent to-accent/90 rounded-full text-white text-xs flex items-center justify-center font-bold shadow-md px-1">
                    {tab.badge > 9 ? "9+" : tab.badge}
                  </div>
                )}
              </div>
              <span className={`text-xs font-medium truncate max-w-full transition-all ${isActive ? 'font-semibold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
