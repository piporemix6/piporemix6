import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { CalendarEvent } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday } from "date-fns";
import { Calendar, MapPin, Edit, Trash2, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface CalendarEventUpdate {
  title?: string;
  description?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
}

export default function CalendarTab() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    startTime: "",
    endTime: "",
    location: "",
  });
  const [naturalTimeInput, setNaturalTimeInput] = useState("");
  const [timeParseMessage, setTimeParseMessage] = useState("");
  
  const { data: events, isLoading } = useQuery<CalendarEvent[]>({
    queryKey: ["/api/calendar/events"],
  });

  const createEventMutation = useMutation({
    mutationFn: async (eventData: { title: string; description: string; startTime: string; endTime: string; location: string }) => {
      const response = await apiRequest("POST", "/api/calendar/events", eventData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
  });

  const updateEventMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: CalendarEventUpdate }) => {
      const response = await apiRequest("PATCH", `/api/calendar/events/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar/events"] });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/calendar/events/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar/events"] });
      setEditingEvent(null);
    },
  });

  const handleAddClick = () => {
    const defaultStart = new Date(selectedDate);
    defaultStart.setHours(9, 0, 0, 0);
    const defaultEnd = new Date(selectedDate);
    defaultEnd.setHours(10, 0, 0, 0);
    
    setIsAddingEvent(true);
    setEditForm({
      title: "",
      description: "",
      startTime: format(defaultStart, "yyyy-MM-dd'T'HH:mm"),
      endTime: format(defaultEnd, "yyyy-MM-dd'T'HH:mm"),
      location: "",
    });
    setNaturalTimeInput("");
    setTimeParseMessage("");
  };

  const handleEditClick = (event: CalendarEvent) => {
    setEditingEvent(event);
    setEditForm({
      title: event.title,
      description: event.description || "",
      startTime: format(new Date(event.startTime), "yyyy-MM-dd'T'HH:mm"),
      endTime: format(new Date(event.endTime), "yyyy-MM-dd'T'HH:mm"),
      location: event.location || "",
    });
    setNaturalTimeInput("");
    setTimeParseMessage("");
  };

  const handleParseNaturalTime = async () => {
    if (!naturalTimeInput.trim()) {
      setTimeParseMessage("");
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/parse-time", {
        timeExpression: naturalTimeInput,
        referenceDate: selectedDate.toISOString(),
      });
      const result = await response.json();

      if (result.status === 'resolved' && result.isoDate && result.isoTime) {
        const startTimeLocal = `${result.isoDate}T${result.isoTime}`;
        
        const startDate = new Date(`${result.isoDate}T${result.isoTime}:00`);
        const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);
        
        const endYear = endDate.getFullYear();
        const endMonth = String(endDate.getMonth() + 1).padStart(2, '0');
        const endDay = String(endDate.getDate()).padStart(2, '0');
        const endHours = String(endDate.getHours()).padStart(2, '0');
        const endMinutes = String(endDate.getMinutes()).padStart(2, '0');
        const endTimeLocal = `${endYear}-${endMonth}-${endDay}T${endHours}:${endMinutes}`;

        setEditForm({
          ...editForm,
          startTime: startTimeLocal,
          endTime: endTimeLocal,
        });
        setTimeParseMessage(`✅ Waktu diset: ${result.isoDate} jam ${result.isoTime}`);
      } else if (result.status === 'needs_clarification') {
        setTimeParseMessage(`⚠️ ${result.clarificationPrompt}`);
      } else {
        setTimeParseMessage("⚠️ Tidak dapat memproses waktu. Silakan coba format lain atau gunakan input manual.");
      }
    } catch (error) {
      setTimeParseMessage("❌ Gagal memproses waktu. Coba lagi!");
      console.error('Error parsing time:', error);
    }
  };

  const handleSaveEvent = () => {
    if (isAddingEvent) {
      createEventMutation.mutate({
        title: editForm.title,
        description: editForm.description,
        startTime: editForm.startTime,
        endTime: editForm.endTime,
        location: editForm.location,
      });
      setIsAddingEvent(false);
    } else if (editingEvent) {
      updateEventMutation.mutate({
        id: editingEvent.id,
        updates: {
          title: editForm.title,
          description: editForm.description,
          startTime: editForm.startTime,
          endTime: editForm.endTime,
          location: editForm.location,
        },
      });
      setEditingEvent(null);
    }
  };

  const handleDeleteEvent = () => {
    if (!editingEvent) return;

    if (confirm("Are you sure you want to delete this event?")) {
      deleteEventMutation.mutate(editingEvent.id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4 pt-16">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const eventsForDate = (date: Date) => {
    return events?.filter(event => 
      isSameDay(new Date(event.startTime), date)
    ) || [];
  };

  const todaysEvents = eventsForDate(new Date());
  const selectedDateEvents = eventsForDate(selectedDate);

  return (
    <div className="pb-20" data-testid="calendar-tab">
      {/* Header */}
      <div className="bg-gradient-to-br from-purple-700 to-pink-800 p-6 pt-12 pb-7 text-white">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center penguin-float shadow-md">
              <PipoMascot size="medium" expression="happy" />
            </div>
            <div>
              <h1 className="text-2xl font-bold mb-0.5 drop-shadow-sm" data-testid="calendar-title">Your Calendar 📅</h1>
              <p className="text-white/95 text-sm">Let's plan your day!</p>
            </div>
          </div>
          <Button
            onClick={handleAddClick}
            size="sm"
            className="flex items-center gap-1.5 bg-white hover:bg-white/90 text-purple-700 shadow-sm transition-all"
            data-testid="button-add-event"
          >
            <Plus className="w-4 h-4" />
            <span className="font-medium">Add</span>
          </Button>
        </div>
      </div>

      <div className="p-5 space-y-6">
        {/* Mini Calendar */}
        <div className="bg-card border border-border rounded-xl p-5 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">
              {format(selectedDate, "MMMM yyyy")}
            </h2>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-xs font-medium text-muted-foreground p-2">
                {day}
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-7 gap-1">
            {monthDays.map((day) => {
              const dayEvents = eventsForDate(day);
              const hasEvents = dayEvents.length > 0;
              const isSelected = isSameDay(day, selectedDate);
              const isCurrentMonth = isSameMonth(day, selectedDate);
              const isCurrentDay = isToday(day);

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDate(day)}
                  className={`
                    relative p-2 text-sm rounded-lg transition-colors
                    ${isSelected ? 'bg-primary text-primary-foreground' : ''}
                    ${isCurrentDay && !isSelected ? 'bg-secondary text-secondary-foreground font-bold' : ''}
                    ${!isCurrentMonth ? 'text-muted-foreground/50' : 'text-foreground'}
                    ${hasEvents && !isSelected ? 'bg-accent/20' : ''}
                    hover:bg-muted
                  `}
                  data-testid={`calendar-day-${format(day, 'yyyy-MM-dd')}`}
                >
                  {format(day, 'd')}
                  {hasEvents && (
                    <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full"></div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Today's Events */}
        {isToday(selectedDate) && todaysEvents.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Today's Events
            </h2>
            <div className="space-y-3">
              {todaysEvents.map((event) => (
                <div key={event.id} className="bg-card border border-border rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow" data-testid={`event-${event.id}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1" data-testid="event-title">
                        {event.title}
                      </h3>
                      {event.description && (
                        <p className="text-sm text-muted-foreground mb-2.5 leading-relaxed">
                          {event.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="shadow-sm">
                          {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                        </Badge>
                        {event.location && (
                          <Badge variant="secondary" className="flex items-center gap-1 shadow-sm">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEditClick(event)}
                      className="hover:bg-muted/50"
                      data-testid={`button-edit-${event.id}`}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Selected Date Events */}
        {!isToday(selectedDate) && selectedDateEvents.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Events for {format(selectedDate, "MMM d, yyyy")}
            </h2>
            <div className="space-y-3">
              {selectedDateEvents.map((event) => (
                <div key={event.id} className="bg-card border border-border rounded-lg p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground mb-1">
                        {event.title}
                      </h3>
                      {event.description && (
                        <p className="text-sm text-muted-foreground mb-2">
                          {event.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline">
                          {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                        </Badge>
                        {event.location && (
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEditClick(event)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!events || events.length === 0) && (
          <div className="text-center py-12" data-testid="empty-calendar">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <PipoMascot size="medium" expression="neutral" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No events yet!</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Chat with me to add events to your calendar! I'll help you stay organized! 🐧📅
            </p>
          </div>
        )}

        {/* No Events for Selected Date */}
        {events && events.length > 0 && selectedDateEvents.length === 0 && !isToday(selectedDate) && (
          <div className="text-center py-8" data-testid="no-events-selected-date">
            <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
              <PipoMascot size="small" expression="neutral" />
            </div>
            <p className="text-sm text-muted-foreground">
              No events scheduled for {format(selectedDate, "MMM d, yyyy")}
            </p>
          </div>
        )}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isAddingEvent || !!editingEvent} onOpenChange={(open) => {
        if (!open) {
          setIsAddingEvent(false);
          setEditingEvent(null);
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isAddingEvent ? "Add Calendar Event" : "Edit Calendar Event"}</DialogTitle>
            <DialogDescription>
              {isAddingEvent ? "Create a new event for your calendar." : "Modify your event details or remove it from your calendar."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Title</label>
              <Input
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                placeholder="Event title"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Description</label>
              <Textarea
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Additional details (optional)"
              />
            </div>
            <div className="border border-primary/20 rounded-lg p-3 bg-primary/5">
              <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                <span>⏰ Tulis Waktu (Bahasa Alami)</span>
              </label>
              <Input
                value={naturalTimeInput}
                onChange={(e) => setNaturalTimeInput(e.target.value)}
                onBlur={handleParseNaturalTime}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleParseNaturalTime();
                  }
                }}
                placeholder='Contoh: "jam 9 pagi", "besok jam 3 sore", "hari ini jam 2 siang"'
                className="mb-2"
              />
              {timeParseMessage && (
                <p className="text-xs text-muted-foreground mt-1">{timeParseMessage}</p>
              )}
              <p className="text-xs text-muted-foreground mt-2">
                💡 Ketik waktu yang Anda inginkan, sistem akan menggunakan waktu tersebut (bukan waktu laptop saat ini). Semua waktu menggunakan zona waktu Jakarta (WIB).
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Start Time</label>
                <Input
                  type="datetime-local"
                  value={editForm.startTime}
                  onChange={(e) => setEditForm({ ...editForm, startTime: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">End Time</label>
                <Input
                  type="datetime-local"
                  value={editForm.endTime}
                  onChange={(e) => setEditForm({ ...editForm, endTime: e.target.value })}
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Location</label>
              <Input
                value={editForm.location}
                onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                placeholder="Event location (optional)"
              />
            </div>
          </div>
          <DialogFooter className="flex gap-2">
            {!isAddingEvent && (
              <>
                <Button
                  variant="destructive"
                  onClick={handleDeleteEvent}
                  disabled={deleteEventMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
                <div className="flex-1" />
              </>
            )}
            <Button variant="outline" onClick={() => {
              setIsAddingEvent(false);
              setEditingEvent(null);
            }}>
              Cancel
            </Button>
            <Button
              onClick={handleSaveEvent}
              disabled={!editForm.title || createEventMutation.isPending || updateEventMutation.isPending}
            >
              {isAddingEvent ? "Create Event" : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
