import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Todo } from "@shared/schema";
import PipoMascot from "./PipoMascot";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { CheckCircle2, Circle, ListTodo, Pencil, Trash2, Plus } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function TodoTab() {
  const [editingTodo, setEditingTodo] = useState<Todo | null>(null);
  const [isAddingTodo, setIsAddingTodo] = useState(false);
  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    priority: "medium" as "high" | "medium" | "low"
  });

  const { data: todos, isLoading } = useQuery<Todo[]>({
    queryKey: ["/api/todos"],
  });

  const createTodoMutation = useMutation({
    mutationFn: async (todoData: { title: string; description: string; priority: string }) => {
      const response = await apiRequest("POST", "/api/todos", todoData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
  });

  const updateTodoMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Todo> }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
    },
  });

  const deleteTodoMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/todos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/todos"] });
      setEditingTodo(null);
    },
  });

  const handleToggleComplete = (todo: Todo) => {
    updateTodoMutation.mutate({
      id: todo.id,
      updates: { isCompleted: !todo.isCompleted }
    });
  };

  const handleAddClick = () => {
    setIsAddingTodo(true);
    setEditForm({
      title: "",
      description: "",
      priority: "medium"
    });
  };

  const handleEditClick = (todo: Todo) => {
    setEditingTodo(todo);
    setEditForm({
      title: todo.title,
      description: todo.description || "",
      priority: todo.priority as "high" | "medium" | "low"
    });
  };

  const handleSaveTodo = () => {
    if (isAddingTodo) {
      createTodoMutation.mutate(editForm);
      setIsAddingTodo(false);
    } else if (editingTodo) {
      updateTodoMutation.mutate({
        id: editingTodo.id,
        updates: editForm
      });
      setEditingTodo(null);
    }
  };

  const handleDeleteTodo = () => {
    if (!editingTodo) return;
    
    if (confirm("Are you sure you want to delete this task?")) {
      deleteTodoMutation.mutate(editingTodo.id);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "outline";
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "🔥 High";
      case "medium":
        return "⚡ Medium";
      case "low":
        return "💤 Low";
      default:
        return "Medium";
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4 pt-16">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  const activeTodos = todos?.filter(t => !t.isCompleted) || [];
  const completedTodos = todos?.filter(t => t.isCompleted) || [];

  return (
    <div className="pb-20" data-testid="todo-tab">
      {/* Header */}
      <div className="bg-gradient-to-br from-green-700 to-blue-800 p-6 pt-12 pb-7 text-white">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center penguin-float shadow-md">
              <PipoMascot size="medium" expression="happy" />
            </div>
            <div>
              <h1 className="text-2xl font-bold mb-0.5 drop-shadow-sm" data-testid="todo-title">Your Tasks 📝</h1>
              <p className="text-white/95 text-sm">Let's tackle them together!</p>
            </div>
          </div>
          <Button
            onClick={handleAddClick}
            size="sm"
            className="flex items-center gap-1.5 bg-white hover:bg-white/90 text-green-700 shadow-sm transition-all"
            data-testid="button-add-todo"
          >
            <Plus className="w-4 h-4" />
            <span className="font-medium">Add</span>
          </Button>
        </div>
      </div>

      <div className="p-5 space-y-6">
        {/* Active Todos */}
        {activeTodos.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <ListTodo className="w-5 h-5 text-primary" />
              To Do ({activeTodos.length})
            </h2>
            <div className="space-y-3">
              {activeTodos.map((todo) => (
                <div 
                  key={todo.id} 
                  className="bg-card border border-border rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                  data-testid={`todo-${todo.id}`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleToggleComplete(todo)}
                      disabled={updateTodoMutation.isPending}
                      className="mt-0.5 text-muted-foreground hover:text-primary transition-colors"
                      data-testid={`button-toggle-${todo.id}`}
                    >
                      <Circle className="w-5 h-5" />
                    </button>
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1" data-testid="todo-title-text">
                        {todo.title}
                      </h3>
                      {todo.description && (
                        <p className="text-sm text-muted-foreground mb-2.5 leading-relaxed" data-testid="todo-description">
                          {todo.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={getPriorityColor(todo.priority)} className="shadow-sm">
                          {getPriorityLabel(todo.priority)}
                        </Badge>
                        <span className="text-xs text-muted-foreground" data-testid="todo-created-date">
                          Created {format(new Date(todo.createdAt), "MMM d")}
                        </span>
                      </div>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditClick(todo)}
                      className="text-muted-foreground hover:text-primary hover:bg-muted/50"
                      data-testid={`button-edit-${todo.id}`}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Completed Todos */}
        {completedTodos.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Completed ({completedTodos.length})
            </h2>
            <div className="space-y-3">
              {completedTodos.map((todo) => (
                <div 
                  key={todo.id} 
                  className="bg-muted/40 border border-border/60 rounded-xl p-4 opacity-70 hover:opacity-80 transition-opacity"
                  data-testid={`completed-todo-${todo.id}`}
                >
                  <div className="flex items-start gap-3">
                    <button
                      onClick={() => handleToggleComplete(todo)}
                      disabled={updateTodoMutation.isPending}
                      className="mt-0.5 text-green-500 hover:text-green-600 transition-colors"
                      data-testid={`button-uncomplete-${todo.id}`}
                    >
                      <CheckCircle2 className="w-5 h-5" />
                    </button>
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground mb-1 line-through decoration-2">
                        {todo.title}
                      </h3>
                      {todo.description && (
                        <p className="text-sm text-muted-foreground mb-2.5 line-through leading-relaxed">
                          {todo.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="opacity-60 bg-green-50 text-green-700 border-green-200">
                          Completed ✓
                        </Badge>
                      </div>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEditClick(todo)}
                      className="text-muted-foreground hover:text-primary hover:bg-muted/50"
                      data-testid={`button-edit-${todo.id}`}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {(!todos || todos.length === 0) && (
          <div className="text-center py-16 px-4" data-testid="empty-todos">
            <div className="w-20 h-20 bg-gradient-to-br from-muted to-muted/60 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-sm">
              <PipoMascot size="medium" expression="neutral" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No tasks yet!</h3>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto leading-relaxed">
              Chat with me to create tasks! I'll help you stay productive! 🐧✅
            </p>
          </div>
        )}

        {/* All tasks completed */}
        {todos && todos.length > 0 && activeTodos.length === 0 && (
          <div className="text-center py-16 px-4" data-testid="all-todos-complete">
            <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-green-50 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-sm">
              <PipoMascot size="medium" expression="excited" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">All tasks completed! 🎉</h3>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto leading-relaxed">
              Great job! You've completed all your tasks! I'm so proud of you! 🐧✨
            </p>
          </div>
        )}
      </div>

      {/* Add/Edit Todo Dialog */}
      <Dialog open={isAddingTodo || !!editingTodo} onOpenChange={(open) => {
        if (!open) {
          setIsAddingTodo(false);
          setEditingTodo(null);
        }
      }}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{isAddingTodo ? "Add New Task" : "Edit Task"}</DialogTitle>
            <DialogDescription>
              {isAddingTodo ? "Create a new task to stay organized." : "Make changes to your task here. Click save when you're done."}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                placeholder="Task title"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Task description (optional)"
                rows={3}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="priority">Priority</Label>
              <Select
                value={editForm.priority}
                onValueChange={(value: "high" | "medium" | "low") => 
                  setEditForm({ ...editForm, priority: value })
                }
              >
                <SelectTrigger id="priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">🔥 High</SelectItem>
                  <SelectItem value="medium">⚡ Medium</SelectItem>
                  <SelectItem value="low">💤 Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-2">
            {!isAddingTodo && (
              <Button
                variant="destructive"
                onClick={handleDeleteTodo}
                disabled={deleteTodoMutation.isPending}
                className="w-full sm:w-auto"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            )}
            <div className="flex gap-2 flex-1">
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddingTodo(false);
                  setEditingTodo(null);
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveTodo}
                disabled={createTodoMutation.isPending || updateTodoMutation.isPending || !editForm.title.trim()}
                className="flex-1"
              >
                {isAddingTodo ? "Create Task" : "Save changes"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
