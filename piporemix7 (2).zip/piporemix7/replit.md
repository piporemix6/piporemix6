# Overview

Pipo Journal is a mobile-first productivity companion application featuring an interactive penguin mascot named Pipo. The app helps users manage their daily tasks, reminders, calendar events, and journal entries through a conversational chat interface with voice and text input capabilities. Built with React and Express, it emphasizes an engaging, gamified user experience with streak tracking for daily journaling.

# Recent Changes

**October 28, 2025 - Professional UI Redesign**
- Redesigned entire UI to balance professional polish with friendly, approachable character
- Updated color system with WCAG AA-compliant gradients (700-800 Tailwind shades for ≥4.5:1 contrast)
- Unique gradient colors per tab for visual variety:
  - Chat: blue-700 to purple-800
  - Tasks: green-700 to blue-800
  - Reminders: amber-700 to orange-800
  - Calendar: purple-700 to pink-800
  - Account: cyan-700 to blue-800
- Enhanced typography with Inter font family for better readability
- Enlarged Pipo mascot to 16x16px in white rounded containers with subtle float animation
- Refined spacing, shadows (shadow-md), and card designs throughout
- Bottom navigation with glassmorphism effect and accessible gradient active state
- Smooth transitions and subtle hover effects for interactive elements
- Conversational microcopy maintained for friendly tone
- Design demonstrates Pipo is suitable for both casual journaling and serious productivity work

**October 28, 2025 - Context-Aware Conversation & Clarification Handling**
- Implemented context-aware conversation system for Pipo
- Pipo can now remember previous questions and process follow-up answers
- Example flow: Pipo asks "mau jam berapa?" → User answers "jam 9" → Pipo creates reminder with that time
- System uses `pending_clarifications` table to store conversation context
- Automatic clarification timeout: clears context if user changes topic
- Seamless integration with existing auto-creation system (reminders, calendar, todos)

**October 28, 2025 - Auto-Creation of To-Do Items from Chat**
- Added automatic to-do item creation from chat messages
- System now detects task-related patterns in both English and Indonesian
- English patterns: "I need to...", "I have to...", "I must...", "I should...", "todo:", "task:"
- Indonesian patterns: "aku harus...", "gue perlu...", "mesti...", "kudu...", "tugas:", "kerjaan:"
- Intelligent priority detection from keywords:
  - High priority: "urgent", "penting", "segera", "asap", "cepat", "mendesak"
  - Low priority: "nanti", "later", "kalau sempat", "if i have time", "someday", "kapan-kapan"
  - Medium priority: default when no priority keywords detected
- To-do items are only auto-created when message doesn't already trigger reminder or calendar creation
- Updated Pipo responses to acknowledge to-do creation in both English and Indonesian
- Frontend automatically refreshes to-do list when items are created from chat

**October 21, 2025 - Natural Language Time Input for Calendar**
- Added natural language time input field in Calendar event dialog
- Users can type Indonesian time expressions like "jam 9 pagi", "besok jam 3 sore", "hari ini jam 2 siang"
- System uses the exact time written (e.g., "jam 9 pagi" = 9:00 AM), not the current laptop time
- New API endpoint `/api/parse-time` for parsing Indonesian time expressions
- All calendar times use Jakarta timezone (WIB) for consistency
- Backend calendar event creation/update now uses `createJakartaDate()` for proper timezone handling
- Clear user feedback with success/error messages during time parsing
- Automatic calculation of end time (1 hour after start time) with proper day rollover handling

**October 20, 2025 - Indonesian Time Parsing System**
- Implemented intelligent Indonesian time expression parsing system
- Parser understands expressions like "jam 6 malam" (18:00), "besok pagi" (tomorrow morning), "hari ini pukul 8"
- Automatic conversion to 24-hour format in Asia/Jakarta timezone
- Reminders stored in format: "[Activity name] — [yyyy-mm-dd] — [HH:mm]"
  - Example: "Makan bersama keluarga — 2025-10-20 — 18:00"
- Intelligent ambiguity detection requests clarification for vague time expressions
  - Examples: "besok sore" or "nanti malam" without specific hour will prompt for exact time
- Supports relative dates: "hari ini" (today), "besok" (tomorrow), "lusa" (day after tomorrow)
- Supports time-of-day descriptors: "pagi" (morning 5-10), "siang" (noon 11-14), "sore" (afternoon 15-17), "malam" (evening/night 18-23)

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Framework & Build Tools**
- React 18 with TypeScript for type safety
- Vite as the build tool and development server with hot module replacement
- Wouter for lightweight client-side routing (single-page application)

**UI Component System**
- Shadcn/UI component library built on Radix UI primitives for accessibility
- Tailwind CSS with CSS variables for theming and responsive design
- Mobile-first design philosophy with bottom tab navigation
- Custom fonts: DM Sans, Architects Daughter, Fira Code, and Geist Mono

**State Management**
- TanStack Query (React Query) for server state management and caching
- Optimistic updates and automatic cache invalidation
- No global client state management (server state driven)

**Key Features**
- Voice recognition using browser's native Speech Recognition API with text fallback
- Real-time chat interface with Pipo mascot
- Multi-language support for voice input
- Badge notifications on navigation tabs for pending items

## Backend Architecture

**Server Framework**
- Express.js server with TypeScript
- ES modules throughout the codebase
- RESTful API design with JSON responses
- Centralized error handling middleware

**Development Setup**
- Hot module replacement integrated with Vite in development mode
- Request logging middleware with response time tracking
- Production build uses esbuild for server bundling

**API Design Pattern**
- Resource-based endpoints (users, chat, reminders, todos, calendar)
- CRUD operations with PATCH for partial updates
- Automatic entity creation from chat messages (intelligent parsing)

## Data Storage

**Database & ORM**
- PostgreSQL as the primary database (configured for Neon serverless)
- Drizzle ORM for type-safe database operations
- Shared schema definitions between client and server using `drizzle-zod`
- UUID-based primary keys with `gen_random_uuid()`

**Schema Design**
- Users table with streak tracking and last journal date
- Journal entries with mood tracking and voice recording flag
- Reminders with completion status and "from Pipo" attribution
- Todos with priority levels (high, medium, low)
- Calendar events with start/end times and location
- Chat messages for conversation history
- Recognized names for tracking people mentioned in conversations

**Development Storage**
- In-memory storage implementation for development/testing
- Interface-based storage abstraction for easy swapping

## Authentication & Session Management

**Current Implementation**
- Demo mode with default user ("default-user")
- No authentication required (development/demo setup)
- Session storage using PostgreSQL via `connect-pg-simple`
- Designed for single-user experience

## Core Features Architecture

**Conversational AI Interface**
- Chat-based interaction with Pipo mascot
- Automatic intent recognition from user messages
- Entity extraction (dates, times, priorities, names)
- Auto-creation of reminders and calendar events from natural language

**Voice Recognition System**
- Browser-based Speech Recognition API
- Multi-language support with language selector
- Fallback to text input when voice unsupported
- Real-time transcript display

**Productivity Tools Integration**
- Reminders: Time-based notifications with completion tracking
- Todos: Priority-based task management with completion status, manual creation via "Add" button with priority selection
- Calendar: Event scheduling with automatic todo creation for events, manual creation via "Add" button with date/time pickers
- Journal: Daily entries with mood tracking and streak gamification

**Manual Input Features (October 2025)**
- Calendar Tab: Direct event creation via "Add" button in header with form dialog for title, description, start/end times, and location
- Todo Tab: Direct task creation via "Add" button in header with form dialog for title, description, and priority level
- Both features complement the existing chat-based auto-creation system

**Gamification**
- Daily journaling streak system
- Visual streak indicators with color progression
- Motivational messages based on streak milestones

**Mobile-First Navigation**
- Bottom tab bar with 5 main sections (Chat, Reminders, Calendar, Todos, Account)
- Real-time badge counts for active reminders and todos
- Responsive gradient headers with Pipo mascot integration

# External Dependencies

## Database Services
- **Neon Database**: PostgreSQL-compatible serverless database with connection pooling via `@neondatabase/serverless`

## UI Component Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives (@radix-ui/react-*)
- **Lucide React**: Icon library for consistent iconography
- **cmdk**: Command menu component for search/command palette
- **Embla Carousel**: Carousel/slider functionality

## Development Tools
- **Drizzle Kit**: Database migration management and schema push
- **Vite Plugins**: Runtime error modal and cartographer for Replit integration

## Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: CSS class name management
- **class-variance-authority**: Variant-based component styling
- **zod**: Schema validation and type inference
- **nanoid**: Unique ID generation